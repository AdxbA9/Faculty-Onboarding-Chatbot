from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from chatbot_reader import ask_bot   

app = FastAPI()

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Simple Chatbot</title>
</head>
<body>
    <h2>Faculty Onboarding Chatbot</h2>
    <form action="/ask" method="post">
        <input type="text" name="question" placeholder="Ask me anything..." size="50">
        <button type="submit">Send</button>
    </form>
    <p><strong>Response:</strong> {response}</p>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def homepage():
    return HTML_TEMPLATE.format(response="")

@app.post("/ask", response_class=HTMLResponse)
async def ask(request: Request):
    form = await request.form()
    question = form.get("question").lower()
    answer = ask_bot(question)   
    return HTML_TEMPLATE.format(response=answer)
