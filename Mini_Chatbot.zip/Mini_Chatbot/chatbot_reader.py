import PyPDF2
 
# Step 1: Load the PDF
file_path = "Faculty_Guide.pdf"  # Update this to your actual PDF file path

with open(file_path, "rb") as file:
    reader = PyPDF2.PdfReader(file)
    all_text = ""
    for page in reader.pages:
        all_text += page.extract_text()

# Step 2: Simple search function
def ask_bot(question):
    if "leave" in question.lower():
        return "Faculty can apply for leave using the HR Portal. Log in, go to 'Leave Request', select your type of leave, and submit."
    elif "lms" in question.lower() or "upload" in question.lower():
        return "Log in to LMS using your university ID. You can upload course materials under each course section."
    elif "it" in question.lower() or "support" in question.lower():
        return "For IT issues, contact helpdesk@university.edu or call 1234."
    elif "course" in question.lower():
        return "To create a new course section, use the Academic Portal and follow the on-screen steps."
    else:
        return "Sorry, I couldn't find an answer in the document."

# Step 3: Try it out!
while True:
    user_q = input("Ask me anything about faculty onboarding: ")
    if user_q.lower() in ["exit", "quit"]:
        break
    response = ask_bot(user_q)
    print("📘 Chatbot:", response)
